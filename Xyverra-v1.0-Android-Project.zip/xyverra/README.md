# Xyverra v1.0 — nozX Project

Android Java starter project with three screens: Home, Tools, and Terminal.

## Build APK through GitHub
1. Create a GitHub repository and upload all files in this project.
2. Push to the `main` branch, or open **Actions → Build Xyverra APK → Run workflow**.
3. Open the completed workflow run and download the `Xyverra-v1.0-debug-apk` artifact.
4. Extract the artifact to get `app-debug.apk`.

## Included
- Dark neon dashboard and feature cards.
- X/Y sliders (local UI values only).
- Clear Xyverra's own app cache.
- Android document picker to copy a selected file into the app-private directory.
- Basic `.sh` runner using Android's `/system/bin/sh` inside the app sandbox, with output log.
- Shortcut to Android overlay permission settings.

## Important technical boundary
The Headlock/Easy Drag/Headtrick cards are UI/configuration placeholders. This project does not patch, inject into, or modify Free Fire/Free Fire MAX, automate aim, or bypass game protections. Android app sandbox permissions mean shell scripts run without root and cannot access protected game data. The speedometer is a placeholder status panel, not a verified in-game FPS/temperature sensor.

## Notes
- The APK produced by this workflow is a **debug APK** for testing, not a Play Store release.
- Inspect `.sh` scripts before running them. They execute commands within the app's available permissions.
- `com.dts.freefireth` is not used as this app's package ID; Xyverra uses `com.nozx.xyverra`.
